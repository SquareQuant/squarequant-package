# squarequant/utils/__init__.py
"""
Utility functions for the SquareQuant package
"""

# This file is intentionally left empty to mark the directory as a Python package