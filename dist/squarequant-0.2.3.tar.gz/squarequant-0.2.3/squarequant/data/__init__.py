# squarequant/data/__init__.py
"""
Data components of the Squarequant package
"""

# This file is intentionally left empty to mark the directory as a Python package