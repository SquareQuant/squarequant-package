# squarequant/monte_carlo/__init__.py
"""
Monte Carlo components of the Squarequant package
"""

# This file is intentionally left empty to mark the directory as a Python package