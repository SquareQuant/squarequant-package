# squarequant/var/__init__.py
"""
Value-at-Risk components of the Squarequant package
"""

# This file is intentionally left empty to mark the directory as a Python package